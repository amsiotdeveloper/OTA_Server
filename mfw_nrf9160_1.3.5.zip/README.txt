This release includes FOTA update from mfw_nrf9160_1.3.4 release to mfw_nrf9160_1.3.5 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.4_to_1.3.5.bin.

Non-wired full modem update can be performed by using new MFW CBOR image format and suitable support from the nRF Connect SDK and device hardware.

This release includes FOTA-TEST images between mfw_nrf9160_1.3.5 release and mfw_nrf9160_1.3.5-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.3.5_to_1.3.5-FOTA-TEST and mfw_nrf9160_update_from_1.3.5-FOTA-TEST_to_1.3.5.

UUID of mfw_nrf9160_1.3.5 is dc8e7aff-5331-409e-be02-5529dffa5537
UUID of mfw_nrf9160_1.3.5-FOTA-TEST is b388ff53-7acb-4fa0-af23-a82288330738